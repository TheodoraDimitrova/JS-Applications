function startApp() {
    sessionStorage.clear();
    showHideMenuLinks();
    showView('viewHome');
    attachAllEvents();
}